package com.pricedb.service;

import com.pricedb.model.Price;
import com.pricedb.model.Product;
import com.pricedb.model.Store;
import com.pricedb.repository.PriceRepository;
import com.pricedb.repository.ProductRepository;
import com.pricedb.repository.StoreRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PriceService {
    private final ProductRepository productRepository;
    private final StoreRepository storeRepository;
    private final PriceRepository priceRepository;

    @Transactional
    public void updatePrice(String productId, String storeId, Double pricePerItem, String updateSource) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        Store store = storeRepository.findById(storeId)
                .orElseThrow(() -> new RuntimeException("Store not found"));

        Price price = priceRepository.findByProductAndStore(product, store)
                .orElse(new Price());

        price.setProduct(product);
        price.setStore(store);
        price.setPricePerItem(pricePerItem);
        price.setLastUpdated(LocalDateTime.now());
        price.setUpdateSource(updateSource);

        priceRepository.save(price);
    }
    public void saveStore(Store store) {
        storeRepository.save(store);
    }

    @Transactional
    public void cleanupOldEntries(LocalDateTime beforeDate) {
        List<Price> oldPrices = priceRepository.findByLastUpdatedBefore(beforeDate);
        priceRepository.deleteAll(oldPrices);
    }

    public List<Price> getAllPrices() {
        return priceRepository.findAll();
    }
    public void saveProduct(Product product) {
      productRepository.save(product);
    }
    public void savePrice(Price price) {
        priceRepository.save(price);
    }
}