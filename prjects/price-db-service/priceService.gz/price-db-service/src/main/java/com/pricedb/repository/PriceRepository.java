package com.pricedb.repository;

import com.pricedb.model.Price;
import com.pricedb.model.Product;
import com.pricedb.model.Store;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface PriceRepository extends JpaRepository<Price, Long> {
    Optional<Price> findByProductAndStore(Product product, Store store);
    List<Price> findByLastUpdatedBefore(LocalDateTime date);
}