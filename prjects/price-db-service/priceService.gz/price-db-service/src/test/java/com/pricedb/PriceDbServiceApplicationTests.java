package com.pricedb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PriceDbServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
